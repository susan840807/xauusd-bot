# XAUUSD Quality Signal Bot

Automated gold signal bot. Scans every 15 minutes and sends Telegram alerts.

## Setup on Render.com

1. Connect this GitHub repo to Render
2. Set environment variables:
   - `TELEGRAM_TOKEN` — your bot token
   - `TELEGRAM_CHAT_ID` — your chat ID
3. Deploy as a Background Worker

## Signal Filters
- London / NY session only
- Min 100 pip potential
- Max 3 signals per day
- Volume spike required
- RSI + MACD aligned
